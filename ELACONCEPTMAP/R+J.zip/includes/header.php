Character: <?php echo $name; ?><br><br>
Trait: <?php echo $trait; ?><br><br>
Quote: <?php echo $quote; ?><br><br>
Status: <?php echo $class; ?><br><br>
Name Info: <?php echo $nameorigin; ?><br><br>
Dialogue Type: <?php echo $dialogue; ?><br><br>
Connections: <br><?php echo $conn; ?>
