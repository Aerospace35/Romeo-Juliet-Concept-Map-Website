<?php
#Crabulet
$class="upper class";
$trait="Non-combative";
$dialogue = "verse";
$quote='"
I do but keep the peace: put up thy sword, <br>
Or manage it to part these men with me. " (Act I, SC 1, L 82)';
$nameorigin="Means \"goodwill\" and originated in Italy";
$conn="<a href=\"?name=romeo\">Romeo (cousin)</a><br>
<a href=\"?name=lmontague\">Lady Montague (aunt)</a><br>
<a href=\"?name=montague\">Montague (uncle)</a><br>
<a href=\"?name=mercutio\">Mercutio (friend)</a><br>";

include("includes/header.php");
?>
