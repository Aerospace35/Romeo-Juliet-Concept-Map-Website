<?php
#Crabulet
$class="upper class";
$trait="hotheaded";
$dialogue = "verse";
$quote='"
What noise is this? Give me my long sword, ho! " (Act I, SC 1, L 93)';
$nameorigin="Originated from an actual politically powerful family in 13th century. More agressive than other political factions.";
$conn="<a href=\"?name=romeo\">Juliet (daughter)</a><br>
<a href=\"?name=lcapulet\">Lady Capulet (wife)</a><br>
<a href=\"?name=nurse\">Nurse (employee)</a><br>
<a href=\"?name=tybalt\">Tybalt (nephew)</a><br>
<a href=\"?name=montague\">Montague (mortal enemy)</a><br>";

include("includes/header.php");
?>
