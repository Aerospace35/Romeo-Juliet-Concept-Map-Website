<?php
#Crabulet
$class="upper class";
$trait="crabby";
$quote='"its about to get crabby" (Act IV, SC 1, L 26)';
$nameorigin="unknown";


include("includes/header.php");
?>
