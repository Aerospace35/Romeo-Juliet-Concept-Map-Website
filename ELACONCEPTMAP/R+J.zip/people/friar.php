<?php
#Crabulet
$class="upper class";
$trait="wise";
$dialogue = "verse";
$quote='"
These violent delights have violent ends
And in their triumph die, like fire and powder,..." (Act II, SC 6)';
$nameorigin="unknown";
$conn="<a href=\"?name=romeo\">Romeo (confidant)</a><br>
<a href=\"#\">Everyone (religious leader)</a><br>";

include("includes/header.php");
?>
