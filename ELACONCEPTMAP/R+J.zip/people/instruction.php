<h2>Click the names below to bring up a character. On this profile there will be some nice little links to other characters, described of course, and they will open that character's profile.
Click the clear button to clear the screen at any point. Enjoy!</h2>
<br><br>
