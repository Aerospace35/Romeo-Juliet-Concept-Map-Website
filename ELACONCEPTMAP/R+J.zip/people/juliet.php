<?php
#Juliet
$class="upper class";
$trait="courageous";
$dialogue = "verse";
$quote='"
O, bid me leap, rather than marry Paris,
From off the battlements of yonder tower;..." (Act IV, SC 1)';
$nameorigin="Latin origin, means \"youthful\"";
$conn="<a href=\"?name=romeo\">Romeo (romantic)</a><br>
<a href=\"?name=lcapulet\">Lady Capulet (mother)</a><br>
<a href=\"?name=capulet\">Capulet (father)</a><br>
<a href=\"?name=nurse\">Nurse (confidant)</a><br>
<a href=\"?name=tybalt\">Tybalt (cousin)</a><br>
<a href=\"?name=paris\">Paris (arranged husband)</a><br>
<a href=\"?name=juliet\">Juliet (killer)</a><br>";

include("includes/header.php");
?>
