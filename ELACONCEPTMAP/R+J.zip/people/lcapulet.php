<?php
#Lady Capulet
$class="upper class";
$name="Lady Capulet";
$dialogue = "verse";
$trait="Preoccupied, scattered";
$quote='"This is the matter.—Nurse, give leave awhile.
We must talk in secret.—Nurse, come back again." (Act I, SC 3)';
$nameorigin="Mother of the Capulet household";
$conn="<a href=\"?name=capulet\">Capulet (husband)</a><br>
<a href=\"?name=juliet\">Juliet (daughter)</a><br>
<a href=\"?name=nurse\">Nurse (confidant and employee)</a><br>
<a href=\"?name=tybalt\">Tybalt (nephew)</a><br>";

include("includes/header.php");
?>
