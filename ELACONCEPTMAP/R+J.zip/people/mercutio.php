<?php
#Mercutio
$class="upper class";
$trait="dramatic";
$dialogue = "verse";
$quote='"[Queen Mab Speech]" (Act IV, SC 1, L 26)';
$nameorigin="Latin origin, means to have flair";
$conn="<a href=\"?name=romeo\">Romeo (friend)</a><br>
<a href=\"?name=benvolio\">Benvolio (friend)</a><br>
<a href=\"?name=prince\">Prince Escalus (cousin)</a><br>
<a href=\"?name=paris\">Paris (cousin)</a><br>
<a href=\"?name=tybalt\">Tybalt (killer)</a><br>";

include("includes/header.php");
?>
