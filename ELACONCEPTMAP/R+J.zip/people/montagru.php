<?php
#Montagru
$class="villan class";
$dialogue = "verse";
$trait="greatest supervillan in Verona";
$quote='"We stole... the statue of Juliet!!" (Act V, SC 4, L 3)';
$nameorigin="Fun fact: montagru is commonly referred to incorrectly as fate. He caused everything in this play.";


include("includes/header.php");
?>
