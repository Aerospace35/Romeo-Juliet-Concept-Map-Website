<?php
#Montague
$class="upper class";
$trait="wealthy, reasonable";
$dialogue = "verse";
$quote='"But I can give thee more,
For I will ray her statue in pure gold,
That whiles Verona by that name is known,
There shall no figure at such rate be set
As that of true and faithful Juliet." (Act V, SC 3, L 309)';
$nameorigin="Head of the Montague household";
$conn="<a href=\"?name=romeo\">Romeo (son)</a><br>
<a href=\"?name=benvolio\">Benvolio (nephew)</a><br>
<a href=\"?name=capulet\">Capulet (mortal enemy)</a><br>";

include("includes/header.php");
?>
