<?php
#Nurse
$class="lower class";
$dialogue = "prose";
$trait="crude";
$quote='"No less! nay, bigger; women grow by men. " (Act I, SC 3)';
$nameorigin="No name given, she is a wet nurse, essentially replacement mother";
$dialogue = "prose";
$conn="<a href=\"?name=juliet\">Juliet (caretakee)</a><br>
<a href=\"?name=capulet\">Capulet (employer)</a><br>";

include("includes/header.php");
?>
