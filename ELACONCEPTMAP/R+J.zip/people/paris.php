<?php
#Paris
$class="upper class";
$trait="Righteous";
$dialogue = "verse";
$quote='"Condemned villain, I do apprehend thee" (Act V, SC 3)';
$nameorigin="His name comes from the Prince of Troy, Paris, in Homer's Illiad";
$house="Royalty";
$conn="<a href=\"?name=prince\">Prince (family)</a><br>
<a href=\"?name=mercutio\">Mercutio (cousin)</a><br>
<a href=\"?name=juliet\">Juliet (prospective bride)</a><br>
<a href=\"?name=romeo\">Romeo (killer)</a><br>";

include("includes/header.php");
?>
