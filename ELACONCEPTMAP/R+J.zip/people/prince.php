<?php
#prince
$name="Prince Escalus";
$class="upper class";
$trait="Authoritative";
$dialogue = "verse";
$quote='"Rebellious subjects, enemies to peace,
Profaners of this neighbour-stained steel,—..." (Act I, SC 1, L 101)';
$nameorigin="Indicates power and strength, originating in Greek borrowed from Latin";
$house="Royalty";
$conn="<a href=\"?name=paris\">Paris (family)</a><br>
<a href=\"?name=mercutio\">Mercutio (cousin)</a><br>
<a href=\"#\">Everyone (subjects)</a><br>";

include("includes/header.php");
?>
