<?php
#Romeo
$class="upper class";
$trait="Romantic";
$dialogue = "verse";
$quote='"But soft, what light through yonder window breaks?
It is the east, and Juliet is the sun." (Act II, SC 2)';
$nameorigin="Greek literature";
$house="Montague";
$conn="<a href=\"?name=juliet\">Juliet (bride)</a><br>
<a href=\"?name=mercutio\">Mercutio (friend)</a><br>
<a href=\"?name=benvolio\">Benvlio (cousin)</a><br>
<a href=\"?name=friar\">Friar (confidant)</a><br>
<a href=\"?name=montague\">Montague (father)</a><br>
<a href=\"?name=romeo\">Romeo (killer)</a><br>";

include("includes/header.php");
?>
