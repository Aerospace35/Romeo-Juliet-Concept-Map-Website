<?php
#Tybalt
$class="upper class";
$trait="Warmongering";
$dialogue = "verse";
$quote='"What, drawn, and talk of peace? I hate the word, As I hate hell, all Montagues, and thee." (Act 1, Scene 1, lines 56-7)';
$nameorigin="Indicates a bold character, could be associated with cats";
$house="Capulet";
$conn="<a href=\"?name=juliet\">Juliet (cousin)</a><br>
<a href=\"?name=capulet\">Capulet (uncle)</a><br>
<a href=\"?name=lcapulet\">Lady Capulet (aunt)</a><br>
<a href=\"?name=romeo\">Romeo (killer)</a><br>";

include("includes/header.php");
?>
